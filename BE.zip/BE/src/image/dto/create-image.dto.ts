export class CreateImageDto {
  filename: string;
}
