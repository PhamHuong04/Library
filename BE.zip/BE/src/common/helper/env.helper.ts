export const configEnvPath = {
  envFilePath: 'src/common/envs/development.env',
  isGlobal: true,
};
