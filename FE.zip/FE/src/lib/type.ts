export type TypeAccess = string | null;
