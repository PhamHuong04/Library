export enum Catagory {
  HISTORY,
  TEXTBOOK,
  NOVEL,
  COMIC,
  POEM,
  SELFHELP,
}
